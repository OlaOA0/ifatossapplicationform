<?php
require_once 'db.php';

$message = "";
$status_msg = "";

// Handle Status Update (Accept / Reject) & Email Notification
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && isset($_POST['application_id'])) {
    $app_id = intval($_POST['application_id']);
    $new_status = $_POST['action'] === 'accept' ? 'Accepted' : 'Rejected';

    // Fetch student details for email notification
    $stmt = $conn->prepare("SELECT first_name, last_name, email, admission_id, program_of_study FROM applications WHERE id = ?");
    $stmt->bind_param("i", $app_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        $student_email = $row['email'];
        $student_name = $row['first_name'] . ' ' . $row['last_name'];
        $admission_id = $row['admission_id'];
        $program = $row['program_of_study'];

        // Update status in database
        $update_stmt = $conn->prepare("UPDATE applications SET status = ? WHERE id = ?");
        $update_stmt->bind_param("si", $new_status, $app_id);
        
        if ($update_stmt->execute()) {
            // Automated Email Notification Setup
            $subject = "i-FATOSS University Admission Status Update";
            $headers = "From: admissions@ifatossuniversity.com\r\n";
            $headers .= "MIME-Version: 1.0\r\n";
            $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

            if ($new_status === 'Accepted') {
                $email_body = "
                    <h2>Congratulations, {$student_name}!</h2>
                    <p>We are thrilled to inform you that your application to study <strong>{$program}</strong> at i-FATOSS University has been <strong>ACCEPTED</strong>[cite: 1].</p>
                    <p>Your Unique Admission ID is: <b style='color: #003366; font-size: 16px;'>{$admission_id}</b></p>
                    <p>Please log in to your portal or visit the university campus to complete your registration and physical clearance.</p>
                    <p>Best regards,<br><strong>i-FATOSS University Admissions Team[cite: 1]</strong></p>
                ";
                $message = "Application for {$student_name} has been ACCEPTED and email notification sent!";
            } else {
                $email_body = "
                    <h2>Application Update: i-FATOSS University[cite: 1]</h2>
                    <p>Dear {$student_name},</p>
                    <p>Thank you for your interest in i-FATOSS University[cite: 1]. After careful review of your application for <strong>{$program}</strong>, we regret to inform you that we are unable to offer you admission at this time.</p>
                    <p>We wish you the very best in your future academic pursuits.</p>
                    <p>Best regards,<br><strong>i-FATOSS University Admissions Team[cite: 1]</strong></p>
                ";
                $message = "Application for {$student_name} has been REJECTED and email notification sent.";
            }

            // Send Email (Uses server's mail function - ensure SMTP/sendmail is configured on your server)
            @mail($student_email, $subject, $email_body, $headers);
            $status_msg = "success";
        } else {
            $message = "Error updating status: " . $conn->error;
            $status_msg = "error";
        }
        $update_stmt->close();
    }
    $stmt->close();
}

// Fetch all applications
$filter = isset($_GET['filter']) ? $_GET['filter'] : 'All';
if ($filter === 'Accepted' || $filter === 'Rejected' || $filter === 'Pending') {
    $stmt = $conn->prepare("SELECT * FROM applications WHERE status = ? ORDER BY id DESC");
    $stmt->bind_param("s", $filter);
    $stmt->execute();
    $applications = $stmt->get_result();
} else {
    $applications = $conn->query("SELECT * FROM applications ORDER BY id DESC");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel | i-FATOSS University Admissions[cite: 1]</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { margin: 0; background-color: #f4f7f6; padding: 20px; }
        
        .header { 
            background: #003366; 
            color: white; 
            padding: 15px 25px; 
            border-radius: 8px; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        
        .header-left {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .header img.logo { 
            width: 55px; 
            height: 55px; 
            object-fit: contain; 
            background: white; 
            padding: 4px; 
            border-radius: 50%;
        }

        .header h1 { margin: 0; font-size: 20px; letter-spacing: 0.5px; }
        .header p { margin: 2px 0 0 0; font-size: 12px; opacity: 0.8; }

        .filters { margin: 20px 0; display: flex; gap: 10px; }
        .filters a { padding: 8px 15px; background: white; color: #003366; text-decoration: none; border-radius: 4px; font-weight: bold; border: 1px solid #ccd5df; }
        .filters a.active { background: #003366; color: white; }
        
        .table-container { background: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; text-align: left; font-size: 14px; }
        th, td { padding: 12px 15px; border-bottom: 1px solid #e1e8ed; }
        th { background: #002244; color: white; }
        
        .badge { padding: 5px 10px; border-radius: 4px; font-weight: bold; font-size: 12px; display: inline-block; }
        .badge.Pending { background: #fff3cd; color: #856404; }
        .badge.Accepted { background: #d4edda; color: #155724; }
        .badge.Rejected { background: #f8d7da; color: #721c24; }
        
        .btn { padding: 6px 12px; border: none; border-radius: 4px; font-weight: bold; cursor: pointer; color: white; font-size: 12px; }
        .btn-accept { background: #28a745; }
        .btn-reject { background: #dc3545; }
        .btn:hover { opacity: 0.9; }
        
        .alert { padding: 12px; margin-bottom: 15px; border-radius: 6px; font-weight: bold; }
        .alert.success { background: #d4edda; color: #155724; }
        .alert.error { background: #f8d7da; color: #721c24; }
        .doc-link { color: #003366; text-decoration: underline; font-weight: 500; }

        .back-link {
            color: white; 
            text-decoration: none; 
            font-size: 14px; 
            background: rgba(255, 255, 255, 0.15); 
            padding: 8px 12px; 
            border-radius: 4px; 
            transition: background 0.2s;
        }
        .back-link:hover {
            background: rgba(255, 255, 255, 0.25);
        }
    </style>
</head>
<body>

<div class="header">
    <div class="header-left">
        <!-- University Logo -->
        <img src="logo.png" alt="i-FATOSS University Logo[cite: 1]" class="logo">
        <div>
            <h1>i-FATOSS University Admin Portal[cite: 1]</h1>
            <p>Admission Applications Management System</p>
        </div>
    </div>
    <a href="index.php" class="back-link">← Back to Portal Form</a>
</div>

<?php if (!empty($message)): ?>
    <div class="alert <?php echo $status_msg; ?>" style="margin-top: 20px;">
        <?php echo $message; ?>
    </div>
<?php endif; ?>

<div class="filters">
    <a href="admin.php?filter=All" class="<?php echo $filter=='All'?'active':''; ?>">All Applications</a>
    <a href="admin.php?filter=Pending" class="<?php echo $filter=='Pending'?'active':''; ?>">Pending</a>
    <a href="admin.php?filter=Accepted" class="<?php echo $filter=='Accepted'?'active':''; ?>">Accepted</a>
    <a href="admin.php?filter=Rejected" class="<?php echo $filter=='Rejected'?'active':''; ?>">Rejected</a>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>Admission ID</th>
                <th>Full Name</th>
                <th>Email / Phone</th>
                <th>Category / Mode</th>
                <th>Program / Faculty</th>
                <th>Documents</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($applications && $applications->num_rows > 0): ?>
                <?php while($row = $applications->fetch_assoc()): ?>
                    <tr>
                        <td><strong><?php echo $row['admission_id'] ? $row['admission_id'] : 'N/A'; ?></strong></td>
                        <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?><br><small><?php echo htmlspecialchars($row['phone']); ?></small></td>
                        <td><?php echo htmlspecialchars($row['application_type']); ?><br><small><?php echo htmlspecialchars($row['study_mode']); ?></small></td>
                        <td><?php echo htmlspecialchars($row['program_of_study']); ?><br><small style="color: #666;"><?php echo htmlspecialchars($row['faculty']); ?></small></td>
                        <td>
                            <?php if(!empty($row['passport_photo'])): ?>
                                <a href="uploads/<?php echo $row['passport_photo']; ?>" target="_blank" class="doc-link">Passport</a><br>
                            <?php endif; ?>
                            <?php if(!empty($row['olevel_sitting1'])): ?>
                                <a href="uploads/<?php echo $row['olevel_sitting1']; ?>" target="_blank" class="doc-link">O'Level 1</a><br>
                            <?php endif; ?>
                            <?php if(!empty($row['olevel_sitting2'])): ?>
                                <a href="uploads/<?php echo $row['olevel_sitting2']; ?>" target="_blank" class="doc-link">O'Level 2</a>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge <?php echo $row['status']; ?>"><?php echo $row['status']; ?></span>
                        </td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="application_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="action" value="accept">
                                <button type="submit" class="btn btn-accept" onclick="return confirm('Accept this applicant and send email notification?');">Accept</button>
                            </form>
                            <form method="POST" style="display:inline; margin-top: 4px;">
                                <input type="hidden" name="application_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="action" value="reject">
                                <button type="submit" class="btn btn-reject" onclick="return confirm('Reject this applicant and send email notification?');">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="8" style="text-align: center; padding: 20px; color: #666;">No applications found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>