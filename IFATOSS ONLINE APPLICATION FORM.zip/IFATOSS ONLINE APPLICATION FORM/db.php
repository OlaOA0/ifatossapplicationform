<?php
$host = "localhost";
$user = "root";       // Replace with your DB username
$pass = "";           // Replace with your DB password
$dbname = "ifatoss_university";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database Connection Failed: " . $conn->connect_error);
}
?>