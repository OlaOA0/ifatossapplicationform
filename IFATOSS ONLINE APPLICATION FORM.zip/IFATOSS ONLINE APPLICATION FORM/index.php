<?php
require_once 'db.php';

$message = "";
$status = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $phone = trim($_POST['phone']);
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];
    $nationality = trim($_POST['nationality']);
    $application_type = $_POST['application_type'];
    $previous_institution = isset($_POST['previous_institution']) ? trim($_POST['previous_institution']) : '';
    $previous_cgpa = isset($_POST['previous_cgpa']) ? trim($_POST['previous_cgpa']) : '';
    $last_year_study = isset($_POST['last_year_study']) ? trim($_POST['last_year_study']) : '';
    $faculty = $_POST['faculty'];
    $program_of_study = trim($_POST['program_of_study']);
    $study_mode = $_POST['study_mode'];

    $upload_dir = 'uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // Passport upload handling
    $passport_name = "";
    if (isset($_FILES['passport']) && $_FILES['passport']['error'] == 0) {
        $allowed = ['jpg', 'jpeg', 'png'];
        $filename = $_FILES['passport']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (in_array($ext, $allowed)) {
            $passport_name = uniqid("IMG_") . '.' . $ext;
            move_uploaded_file($_FILES['passport']['tmp_name'], $upload_dir . $passport_name);
        } else {
            $message = "Invalid image file format for Passport. Only JPG, JPEG, and PNG are allowed.";
            $status = "error";
        }
    }

    // O'Level Results upload handling
    $olevel_sitting1_name = "";
    $olevel_sitting2_name = "";
    $allowed_doc_exts = ['jpg', 'jpeg', 'png', 'pdf'];

    if (empty($message) && isset($_FILES['olevel_sitting1']) && $_FILES['olevel_sitting1']['error'] == 0) {
        $filename = $_FILES['olevel_sitting1']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, $allowed_doc_exts)) {
            $olevel_sitting1_name = uniqid("OLEVEL1_") . '.' . $ext;
            move_uploaded_file($_FILES['olevel_sitting1']['tmp_name'], $upload_dir . $olevel_sitting1_name);
        } else {
            $message = "Invalid file format for O'Level 1st Sitting. Allowed formats: PDF, JPG, JPEG, PNG.";
            $status = "error";
        }
    }

    if (empty($message) && isset($_FILES['olevel_sitting2']) && $_FILES['olevel_sitting2']['error'] == 0) {
        $filename = $_FILES['olevel_sitting2']['name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        if (in_array($ext, $allowed_doc_exts)) {
            $olevel_sitting2_name = uniqid("OLEVEL2_") . '.' . $ext;
            move_uploaded_file($_FILES['olevel_sitting2']['tmp_name'], $upload_dir . $olevel_sitting2_name);
        } else {
            $message = "Invalid file format for O'Level 2nd Sitting. Allowed formats: PDF, JPG, JPEG, PNG.";
            $status = "error";
        }
    }

    if (empty($message)) {
        // Note: admission_id will be updated right after insertion
        $stmt = $conn->prepare("INSERT INTO applications (first_name, last_name, email, phone, gender, dob, nationality, application_type, previous_institution, previous_cgpa, last_year_study, faculty, program_of_study, study_mode, passport_photo, olevel_sitting1, olevel_sitting2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssssssssssss", $first_name, $last_name, $email, $phone, $gender, $dob, $nationality, $application_type, $previous_institution, $previous_cgpa, $last_year_study, $faculty, $program_of_study, $study_mode, $passport_name, $olevel_sitting1_name, $olevel_sitting2_name);

        if ($stmt->execute()) {
            $last_id = $conn->insert_id;
            // Generate unique admission ID format: IFATOSS/2026/0001
            $admission_id = "IFATOSS/" . date("Y") . "/" . str_pad($last_id, 4, "0", STR_PAD_LEFT);

            // Save the generated admission ID back to the record
            $update_stmt = $conn->prepare("UPDATE applications SET admission_id = ? WHERE id = ?");
            $update_stmt->bind_param("si", $admission_id, $last_id);
            $update_stmt->execute();
            $update_stmt->close();

            $message = "Application submitted successfully!<br>Your Unique Admission ID is: <strong style='font-size: 18px; color: #003366;'>{$admission_id}</strong><br>Welcome to i-FATOSS University!";
            $status = "success";
        } else {
            if ($conn->errno == 1062) {
                $message = "An application with this email address already exists.";
            } else {
                $message = "Error submitting application: " . $stmt->error;
            }
            $status = "error";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Admission Application | i-FATOSS University Benin</title>
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        
        body { 
            margin: 0; 
            padding: 50px 20px 20px 20px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            overflow-x: hidden;
            background-color: #001f3f;
        }

        .resumption-ticker {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            background: linear-gradient(90deg, #ffcc00, #ff9900);
            color: #002244;
            padding: 10px 0;
            font-weight: bold;
            font-size: 14px;
            z-index: 1000;
            overflow: hidden;
            white-space: nowrap;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            letter-spacing: 0.5px;
        }

        .ticker-content {
            display: inline-block;
            padding-left: 100%;
            animation: tickerScroll 28s linear infinite;
        }

        .ticker-content span {
            display: inline-block;
            padding-right: 50px;
        }

        @keyframes tickerScroll {
            0% { transform: translate3d(0, 0, 0); }
            100% { transform: translate3d(-100%, 0, 0); }
        }

        .bg-slideshow {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -2;
        }

        .bg-slide {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-size: cover;
            background-position: center;
            opacity: 0;
            animation: zoomFade 18s infinite;
        }

        .bg-slide:nth-child(1) { background-image: url('bg1.jpg'); animation-delay: 0s; }
        .bg-slide:nth-child(2) { background-image: url('bg2.jpg'); animation-delay: 6s; }
        .bg-slide:nth-child(3) { background-image: url('bg3.jpg'); animation-delay: 12s; }

        @keyframes zoomFade {
            0% { opacity: 0; transform: scale(1); }
            8% { opacity: 1; }
            33% { opacity: 1; transform: scale(1.08); }
            41% { opacity: 0; transform: scale(1.1); }
            100% { opacity: 0; transform: scale(1); }
        }

        .bg-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 15, 35, 0.72);
            z-index: -1;
            backdrop-filter: blur(4px);
        }

        #loader-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.95);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.5s ease, visibility 0.5s ease;
        }

        #loader-overlay.hidden {
            opacity: 0;
            visibility: hidden;
        }

        @keyframes pulseLogo {
            0% { transform: scale(0.95); opacity: 0.8; }
            50% { transform: scale(1.05); opacity: 1; filter: drop-shadow(0 0 15px rgba(0, 51, 102, 0.2)); }
            100% { transform: scale(0.95); opacity: 0.8; }
        }

        .loader-logo {
            width: 180px;
            height: auto;
            animation: pulseLogo 1.8s infinite ease-in-out;
            margin-bottom: 15px;
        }

        .loader-text {
            color: #003366;
            font-weight: 600;
            font-size: 15px;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        @keyframes fadeInSlide {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .container { 
            width: 100%;
            max-width: 750px; 
            background: rgba(255, 255, 255, 0.95); 
            backdrop-filter: blur(10px);
            padding: 40px; 
            border-radius: 12px; 
            box-shadow: 0 15px 35px rgba(0,0,0,0.3); 
            animation: fadeInSlide 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
            margin: 20px auto;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .header { 
            text-align: center; 
            border-bottom: 2px solid #003366; 
            padding-bottom: 20px; 
            margin-bottom: 25px; 
        }

        .logo-container {
            margin-bottom: 15px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .header img.logo { 
            width: 130px; 
            height: auto; 
            max-height: 130px;
            object-fit: contain;
            transition: transform 0.3s ease;
        }
        .header img.logo:hover {
            transform: scale(1.05);
        }

        .header h1 { color: #003366; margin: 0; font-size: 24px; text-transform: uppercase; letter-spacing: 0.5px; }
        .header p { color: #555; margin-top: 6px; font-size: 14px; font-weight: 500; }
        
        h3 { color: #003366; border-left: 4px solid #003366; padding-left: 10px; margin-top: 25px; margin-bottom: 15px; font-size: 16px; }

        .form-group { margin-bottom: 18px; }
        .form-row { display: flex; gap: 15px; }
        .form-row .form-group { flex: 1; }
        
        label { display: block; font-weight: 600; margin-bottom: 6px; color: #333; font-size: 13px; }
        
        input, select { 
            width: 100%; 
            padding: 12px; 
            border: 1px solid #ccd5df; 
            border-radius: 6px; 
            font-size: 14px; 
            transition: all 0.3s ease;
            background-color: #fafbfc;
        }
        
        input:focus, select:focus { 
            border-color: #003366; 
            box-shadow: 0 0 0 3px rgba(0, 51, 102, 0.15);
            background-color: #fff;
            outline: none; 
        }

        .transfer-section {
            display: none;
            background: #f0f4f8;
            padding: 15px;
            border-radius: 6px;
            border: 1px solid #d0dbe5;
            margin-bottom: 18px;
        }

        @keyframes popIn {
            0% { opacity: 0; transform: scale(0.95); }
            100% { opacity: 1; transform: scale(1); }
        }

        .alert { 
            padding: 14px; 
            margin-bottom: 20px; 
            border-radius: 6px; 
            text-align: center; 
            font-weight: normal;
            line-height: 1.6;
            animation: popIn 0.4s ease forwards;
        }
        .alert.success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .alert.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }

        button { 
            background-color: #003366; 
            color: white; 
            padding: 14px 20px; 
            border: none; 
            border-radius: 6px; 
            font-size: 16px; 
            cursor: pointer; 
            width: 100%; 
            font-weight: bold; 
            transition: background-color 0.2s ease, transform 0.1s ease;
            box-shadow: 0 4px 12px rgba(0, 51, 102, 0.2);
            margin-top: 10px;
        }
        
        button:hover { background-color: #002244; }
        button:active { transform: scale(0.98); }

        @media (max-width: 768px) {
            body { padding: 45px 10px 10px 10px; }
            .container { padding: 20px; border-radius: 8px; }
            .form-row { flex-direction: column; gap: 0; }
            .header h1 { font-size: 20px; }
            .header p { font-size: 12px; }
            .header img.logo { width: 100px; }
            .resumption-ticker { font-size: 12px; padding: 8px 0; }
        }
    </style>
</head>
<body>

<div class="resumption-ticker">
    <div class="ticker-content">
        <span>📢 **RESUMPTION NOTICE:** Welcome to i-FATOSS University, Cotonou, Republic of Benin! Registration and academic lectures for the new session are officially ongoing. Submit your admission application today! 🎓</span>
    </div>
</div>

<div class="bg-slideshow">
    <div class="bg-slide"></div>
    <div class="bg-slide"></div>
    <div class="bg-slide"></div>
</div>
<div class="bg-overlay"></div>

<div id="loader-overlay">
    <img src="loader-logo.jpg" alt="i-FATOSS University Loading" class="loader-logo">
    <div class="loader-text">Loading Portal...</div>
</div>

<div class="container">
    <div class="header">
        <div class="logo-container">
            <img src="logo.png" alt="i-FATOSS University Logo" class="logo">
        </div>
        <h1>i-FATOSS University</h1>
        <p>Cotonou, Republic of Benin | Online Admission Application</p>
    </div>

    <?php if (!empty($message)): ?>
        <div class="alert <?php echo $status; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form action="index.php" method="POST" enctype="multipart/form-data" id="applicationForm">
        
        <h3>Application Details</h3>
        <div class="form-row">
            <div class="form-group">
                <label for="application_type">Application Category *</label>
                <select id="application_type" name="application_type" onchange="toggleTransferFields()" required>
                    <option value="Fresh Student">Fresh Student (First Year)</option>
                    <option value="Transfer Student">Transfer Student (Direct Entry / Credit Transfer)</option>
                    <option value="Distance Learning">Distance Learning / Online Student</option>
                </select>
            </div>
            <div class="form-group">
                <label for="study_mode">Study Mode *</label>
                <select id="study_mode" name="study_mode" required>
                    <option value="Full-Time">Full-Time (On Campus)</option>
                    <option value="Part-Time">Part-Time</option>
                    <option value="Online/Distance">Distance / Online Learning</option>
                </select>
            </div>
        </div>

        <!-- Dynamic Transfer Fields -->
        <div id="transfer-details" class="transfer-section">
            <div class="form-group">
                <label for="previous_institution">Previous Institution Name</label>
                <input type="text" id="previous_institution" name="previous_institution" placeholder="e.g. University of Lagos">
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label for="previous_cgpa">Previous CGPA / Grade</label>
                    <input type="text" id="previous_cgpa" name="previous_cgpa" placeholder="e.g. 3.50 / 5.00 or Upper Credit">
                </div>
                <div class="form-group">
                    <label for="last_year_study">Last Year / Level Completed</label>
                    <input type="text" id="last_year_study" name="last_year_study" placeholder="e.g. 200 Level / 2023">
                </div>
            </div>
        </div>

        <h3>Personal Details</h3>
        <div class="form-row">
            <div class="form-group">
                <label for="first_name">First Name *</label>
                <input type="text" id="first_name" name="first_name" required>
            </div>
            <div class="form-group">
                <label for="last_name">Last Name *</label>
                <input type="text" id="last_name" name="last_name" required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="email">Email Address *</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number *</label>
                <input type="tel" id="phone" name="phone" placeholder="+229 / +234..." required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="dob">Date of Birth *</label>
                <input type="date" id="dob" name="dob" required>
            </div>
            <div class="form-group">
                <label for="gender">Gender *</label>
                <select id="gender" name="gender" required>
                    <option value="">-- Select Gender --</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label for="nationality">Nationality *</label>
            <input type="text" id="nationality" name="nationality" required>
        </div>

        <h3>Academic Program Selection</h3>
        <div class="form-group">
            <label for="faculty">Faculty *</label>
            <select id="faculty" name="faculty" onchange="updateCourseDropdown()" required>
                <option value="">-- Select Faculty First --</option>
                <option value="Faculty of Social Sciences & Management">Faculty of Social Sciences & Management</option>
                <option value="Faculty of Applied Sciences & Technology">Faculty of Applied Sciences & Technology</option>
                <option value="Faculty of Arts & Humanities">Faculty of Arts & Humanities</option>
            </select>
        </div>

        <div class="form-group">
            <label for="program_of_study">Course / Program *</label>
            <select id="program_of_study" name="program_of_study" required>
                <option value="">-- Select Faculty First --</option>
            </select>
        </div>

        <h3>Document Uploads</h3>
        <div class="form-group">
            <label for="passport">Passport Photograph (JPG/PNG) *</label>
            <input type="file" id="passport" name="passport" accept="image/jpeg, image/png">
        </div>

        <div class="form-group">
            <label for="olevel_sitting1">O'Level Result (1st Sitting) * (PDF, JPG, PNG)</label>
            <input type="file" id="olevel_sitting1" name="olevel_sitting1" accept=".pdf, image/jpeg, image/png" required>
        </div>

        <div class="form-group">
            <label for="olevel_sitting2">O'Level Result (2nd Sitting - Optional) (PDF, JPG, PNG)</label>
            <input type="file" id="olevel_sitting2" name="olevel_sitting2" accept=".pdf, image/jpeg, image/png">
        </div>

        <button type="submit" id="submitBtn">Submit Application</button>
    </form>
</div>

<script>
    window.addEventListener('load', function() {
        setTimeout(function() {
            const loader = document.getElementById('loader-overlay');
            loader.classList.add('hidden');
        }, 600);
    });

    document.getElementById('applicationForm').addEventListener('submit', function() {
        const loader = document.getElementById('loader-overlay');
        loader.classList.remove('hidden');
        document.querySelector('.loader-text').innerText = "Submitting Application...";
    });

    const coursesByFaculty = {
        "Faculty of Social Sciences & Management": [
            "Accounting",
            "Business Administration",
            "Banking & Finance",
            "International Relations & Diplomacy",
            "Mass Communication & Journalism",
            "Political Science",
            "Public Administration",
            "Economics",
            "Marketing"
        ],
        "Faculty of Applied Sciences & Technology": [
            "Computer Science",
            "Information Technology",
            "Software Engineering",
            "Cyber Security",
            "Microbiology",
            "Biochemistry",
            "Nursing & Public Health"
        ],
        "Faculty of Arts & Humanities": [
            "English Language & Literature",
            "Linguistics",
            "History & International Studies",
            "Theatre Arts & Media Studies"
        ]
    };

    function updateCourseDropdown() {
        const facultySelect = document.getElementById("faculty");
        const courseSelect = document.getElementById("program_of_study");
        const selectedFaculty = facultySelect.value;

        courseSelect.innerHTML = '<option value="">-- Select Course --</option>';

        if (selectedFaculty && coursesByFaculty[selectedFaculty]) {
            coursesByFaculty[selectedFaculty].forEach(function(course) {
                const option = document.createElement("option");
                option.value = course;
                option.textContent = course;
                courseSelect.appendChild(option);
            });
        } else {
            courseSelect.innerHTML = '<option value="">-- Select Faculty First --</option>';
        }
    }

    function toggleTransferFields() {
        const appType = document.getElementById("application_type").value;
        const transferBox = document.getElementById("transfer-details");
        if (appType === "Transfer Student") {
            transferBox.style.display = "block";
        } else {
            transferBox.style.display = "none";
        }
    }
</script>

</body>
</html>